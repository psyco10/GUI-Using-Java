import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class TeacherGUI
{
    ArrayList<Teacher> list0 = new ArrayList<Teacher>();
    private JFrame jf;
    private JPanel panel1;
    private JLabel l1, l3,l4,l5,l25,l24,l23,l6,l26,l002,l27,l9,l7,jl1,jl3,jl4,jl5,jl25,jl24,jl23,jl26,jl9,jl28,jl6,jl002,jl7,jl27;
    private JTextField t3,t4,t5,t35,t24,t23,t6,t26,t27,t9,t8,jt3,jt4,jt5,jt25,jt24,jt23,jt26,jt9,jt28,jt6,jt8,jt27;
    private JButton b1,b3,b2, b4, b5,jb1,jb2,jb3,jb6,jb4,jb5;
    public void m1()
    {
        JFrame jf = new JFrame("Lecturer GUI");
        jf.setSize(1300,760);
        jf.setLayout(null);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel l1 = new JLabel("Lecturer");
        l1.setBounds(500, 20, 350, 50);
        Font headingFont = new Font("Algerian", Font.BOLD, 45);
        l1.setFont(headingFont);
        l1.setForeground(new Color(0,0,0));
        jf.add(l1);

        
        JLabel l3 = new JLabel("Teacher ID");
        l3.setBounds(20, 100, 300, 40);
        l3.setForeground(new Color(0,0,0));
        Font semiheadingFont1 = new Font("Arial", Font.BOLD, 25);
        l3.setFont(semiheadingFont1);
        jf.add(l3);

        JTextField t3 = new JTextField();
        t3.setBounds(350, 100, 150, 25);
        Font semiheadingFont2 = new Font("Arial", Font.BOLD, 18);
        t3.setFont(semiheadingFont2);
        jf.add(t3);

        JLabel l4 = new JLabel("Teacher Name");
        l4.setBounds(20, 130, 300, 40);
        l4.setForeground(new Color(0,0,0));
        Font semiheadingFont3 = new Font("Arial", Font.BOLD, 25);
        l4.setFont(semiheadingFont3);
        jf.add(l4);

        JTextField t4 = new JTextField();
        t4.setBounds(350, 130, 150, 25);
        Font semiheadingFont4 = new Font("Arial", Font.BOLD, 18);
        t4.setFont(semiheadingFont4);
        jf.add(t4);

        JLabel l5 = new JLabel("Address");
        l5.setBounds(20, 160, 300, 40);
        l5.setForeground(new Color(0,0,0));
        Font semiheadingFont5 = new Font("Arial", Font.BOLD, 25);
        l5.setFont(semiheadingFont5);
        jf.add(l5);

        JTextField t5 = new JTextField();
        t5.setBounds(350, 160, 150, 25);
        Font semiheadingFont6 = new Font("Arial", Font.BOLD, 18);
        t5.setFont(semiheadingFont6);
        jf.add(t5);

        JLabel l6 = new JLabel("Year of Experience");
        l6.setBounds(20, 190, 300, 40);
        l6.setForeground(new Color(0,0,0));
        Font semiheadingFont7 = new Font("Arial", Font.BOLD, 25);
        l6.setFont(semiheadingFont7);
        jf.add(l6);

        JTextField t6 = new JTextField();
        t6.setBounds(350, 190, 150, 25);
        Font semiheadingFont8 = new Font("Arial", Font.BOLD, 18);
        t6.setFont(semiheadingFont8);
        jf.add(t6);

        //right side=====================================================================
        JLabel l23 = new JLabel("Department");
        l23.setBounds(700, 100, 300, 40);
        l23.setForeground(new Color(0,0,0));
        Font semiheadingFont21 = new Font("Arial", Font.BOLD, 25);
        l23.setFont(semiheadingFont21);
        jf.add(l23);

        JTextField t23 = new JTextField();
        t23.setBounds(1100, 100, 150, 25);
        Font semiheadingFont22 = new Font("Arial", Font.BOLD, 18);
        t23.setFont(semiheadingFont22);
        jf.add(t23);

        JLabel l24 = new JLabel("Employment Status");
        l24.setBounds(700, 130, 300, 40);
        l24.setForeground(new Color(0,0,0));
        Font semiheadingFont23 = new Font("Arial", Font.BOLD, 25);
        l24.setFont(semiheadingFont23);
        jf.add(l24);

        JTextField t24 = new JTextField();
        t24.setBounds(1100, 130, 150, 25);
        Font semiheadingFont24 = new Font("Arial", Font.BOLD, 18);
        t24.setFont(semiheadingFont24);
        jf.add(t24);

        JLabel l25 = new JLabel("Working Type");
        l25.setBounds(700, 160, 300, 40);
        l25.setForeground(new Color(0,0,0));
        Font semiheadingFont25 = new Font("Arial", Font.BOLD, 25);
        l25.setFont(semiheadingFont25);
        jf.add(l25);

        JTextField t25 = new JTextField();
        t25.setBounds(1100, 160, 150, 25);
        Font semiheadingFont26 = new Font("Arial", Font.BOLD, 18);
        t25.setFont(semiheadingFont26);
        jf.add(t25);

        JLabel l26 = new JLabel("Working Hours");
        l26.setBounds(700, 190, 300, 40);
        l26.setForeground(new Color(0,0,0));
        Font semiheadingFont27 = new Font("Arial", Font.BOLD, 25);
        l26.setFont(semiheadingFont27);
        jf.add(l26);

        JTextField t26 = new JTextField();
        t26.setBounds(1100, 190, 150, 25);
        Font semiheadingFont28 = new Font("Arial", Font.BOLD, 18);
        t26.setFont(semiheadingFont28);
        jf.add(t26);

        JButton b1 = new JButton("Change to Tutor");
        b1.setBounds(1125, 660, 130, 32);
        Font semiheadingFont01 = new Font("Arial", Font.BOLD, 12);
        b1.setFont(semiheadingFont01);
        jf.add(b1);
        b1.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae)
                {
                    jf.dispose();
                    m2();
                }
            });
        //===================================================================
        JButton b3 = new JButton("Add Lecturer");
        b3.setBounds(125, 300, 130, 32);
        Font semiheadingFont03 = new Font("Arial", Font.BOLD, 12);
        b3.setFont(semiheadingFont03);
        jf.add(b3);

        b3.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            try {
            int teacherId = Integer.parseInt(t3.getText());
            String teacherName = t4.getText();
            String address = t5.getText();
            int yearsOfExperience = Integer.parseInt(t6.getText());
            String department = t23.getText();
            String  employmentStatus= t24.getText();
            String workingType = t25.getText();
            int workingHours = Integer.parseInt(t26.getText());
                         // Check if a Tutor with the same teacherId already exists
            boolean exists = false;
            for (Teacher L1 : list0) {
                if (L1 instanceof Lecturer && L1.getTeacherId() == teacherId) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                JOptionPane.showMessageDialog(null, "Lecturer with ID " + teacherId + " already exists!");
            } else {
                // Create a Tutor object and add to the ArrayList if the ID is not found
                Lecturer L1 = new Lecturer(teacherId,teacherName,address,workingType,employmentStatus,department,yearsOfExperience,workingHours);
                        list0.add(L1);
                        JOptionPane.showMessageDialog(null, "!!!Thank You!!! Lecturer is Added Sucessfull");
                    }    
                    } catch(Exception e){
                        JOptionPane.showMessageDialog(null, "Enter Correct Information of Lecturer To Add Lecturer");
                    }
                }
        });

        //Grade Assignment=================================================

        JLabel l002 = new JLabel("Graded Assingments");
        l002.setBounds(400, 400, 550, 50);
        Font headingFont2 = new Font("Algerian", Font.BOLD, 45);
        l002.setFont(headingFont2);
        l002.setForeground(new Color(0,0,0));
        jf.add(l002);

        JLabel l27 = new JLabel("Score");
        l27.setBounds(700, 520, 300, 40);
        l27.setForeground(new Color(0,0,0));
        Font semiheadingFont29 = new Font("Arial", Font.BOLD, 25);
        l27.setFont(semiheadingFont29);
        jf.add(l27);

        JTextField t27 = new JTextField();
        t27.setBounds(800, 520, 150, 30);
        Font semiheadingFont30 = new Font("Arial", Font.BOLD, 18);
        t27.setFont(semiheadingFont30);
        jf.add(t27);

        JLabel l7 = new JLabel("Year of Experience");
        l7.setBounds(60, 520, 300, 40);
        l7.setForeground(new Color(0,0,0));
        Font semiheadingFont9 = new Font("Arial", Font.BOLD, 25);
        l7.setFont(semiheadingFont9);
        jf.add(l7);

        JTextField t8 = new JTextField();
        t8.setBounds(350, 520, 150, 25);
        Font semiheadingFont10 = new Font("Arial", Font.BOLD, 18);
        t8.setFont(semiheadingFont10);
        jf.add(t8);

        JLabel l9 = new JLabel("Department");
        l9.setBounds(60, 600, 300, 40);
        l9.setForeground(new Color(0,0,0));
        Font semiheadingFont12 = new Font("Arial", Font.BOLD, 25);
        l9.setFont(semiheadingFont9);
        jf.add(l9);

        JTextField t9 = new JTextField();
        t9.setBounds(350, 600, 150, 25);
        Font semiheadingFont13 = new Font("Arial", Font.BOLD, 18);
        t9.setFont(semiheadingFont10);
        jf.add(t9);

        //grade assignment button ===========================================

        JButton b4 = new JButton("Clear");
        b4.setBounds(700, 600, 130, 32);
        Font semiheadingFont04 = new Font("Arial", Font.BOLD, 12);
        b4.setFont(semiheadingFont04);
        jf.add(b4);

        b4.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    t3.setText("");
                    t4.setText("");
                    t5.setText("");
                    t6.setText("");
                    t23.setText("");
                    t24.setText("");
                    t25.setText("");
                    t26.setText("");
                    t27.setText("");
                    t8.setText("");
                    JOptionPane.showMessageDialog(null, "Cleared");
                }

        });

        //===================================================================================
        JButton b5 = new JButton("Graded Assignments");
        b5.setBounds(125, 660, 180, 32);
        Font semiheadingFont05 = new Font("Arial", Font.BOLD, 12);
        b5.setFont(semiheadingFont05);
        jf.add(b5);

        b5.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    try {
                        int score = Integer.parseInt(t27.getText());
                        int YearsOfExperience = Integer.parseInt(t8.getText());
                        String Department = t23.getText();
                        for(Teacher t :list0){
                            if (t instanceof Lecturer){
                                //downcasting
                                Lecturer L1 = (Lecturer) t;
                                L1.gradeAssignment(score,Department,YearsOfExperience);

                            }
                        }
                        JOptionPane.showMessageDialog(null, "!!!Thank You!!! Graded Score Sucessfull");
                    } catch(Exception e){
                        JOptionPane.showMessageDialog(null, "enter Correct Information to Add Graded Score");
                        
                    }
                }
        });

        //=============================================================
        JButton b2 = new JButton("Display");
        b2.setBounds(1025, 300, 130, 32);
        Font semiheadingFont02 = new Font("Arial", Font.BOLD, 12);
        b2.setFont(semiheadingFont02);
        jf.add(b2);

       b2.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent ae) {
        boolean hasLecturers = false;
        
        StringBuilder details = new StringBuilder();
        for (Teacher T : list0) { // Ensure 'list' is the correct name of your teacher list variable
            if (T instanceof Lecturer) {
                if (!hasLecturers) { // Only set to true the first time a lecturer is found
                    hasLecturers = true;
                }
                Lecturer lecturer = (Lecturer) T;
                
                lecturer.displayDetails();
                
            }
        }

        if (!hasLecturers) {
            JOptionPane.showMessageDialog(null, "No Lecturer Added");
        } else {
            JOptionPane.showMessageDialog(null, "Lecturer Details are Displayed\n" + details.toString());
        }
    }
});

        //===================================================================

        jf.setVisible(true);
        jf.setResizable(true);

        JPanel Panel1 = new JPanel();
        Panel1.setBounds(0,0,1300,760);
        Panel1.setBackground(Color.GRAY);
        jf.add(Panel1);

    }
//=======================================================================================================
    public void m2()
    {
        JFrame jf = new JFrame("Tutor GUI");
        jf.setSize(1300,760);
        jf.setLayout(null);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel jl1 = new JLabel("Tutor");
        jl1.setBounds(550, 20, 350, 50);
        Font headingFont = new Font("Algerian", Font.BOLD, 45);
        jl1.setFont(headingFont);
        jl1.setForeground(new Color(0,0,0));
        jf.add(jl1);

        
        JLabel jl3 = new JLabel("Teacher ID");
        jl3.setBounds(20, 100, 300, 40);
        jl3.setForeground(new Color(0,0,0));
        Font semiheadingFont1 = new Font("Arial", Font.BOLD, 25);
        jl3.setFont(semiheadingFont1);
        jf.add(jl3);

        JTextField jt3 = new JTextField();
        jt3.setBounds(350, 100, 150, 25);
        Font semiheadingFont2 = new Font("Arial", Font.BOLD, 18);
        jt3.setFont(semiheadingFont2);
        jf.add(jt3);

        JLabel jl4 = new JLabel("Teacher Name");
        jl4.setBounds(20, 130, 300, 40);
        jl4.setForeground(new Color(0,0,0));
        Font semiheadingFont3 = new Font("Arial", Font.BOLD, 25);
        jl4.setFont(semiheadingFont3);
        jf.add(jl4);

        JTextField jt4 = new JTextField();
        jt4.setBounds(350, 130, 150, 25);
        Font semiheadingFont4 = new Font("Arial", Font.BOLD, 18);
        jt4.setFont(semiheadingFont4);
        jf.add(jt4);

        JLabel jl5 = new JLabel("Address");
        jl5.setBounds(20, 160, 300, 40);
        jl5.setForeground(new Color(0,0,0));
        Font semiheadingFont5 = new Font("Arial", Font.BOLD, 25);
        jl5.setFont(semiheadingFont5);
        jf.add(jl5);

        JTextField jt5 = new JTextField();
        jt5.setBounds(350, 160, 150, 25);
        Font semiheadingFont6 = new Font("Arial", Font.BOLD, 18);
        jt5.setFont(semiheadingFont6);
        jf.add(jt5);

        JLabel jl6 = new JLabel("Performance Index");
        jl6.setBounds(20, 190, 300, 40);
        jl6.setForeground(new Color(0,0,0));
        Font semiheadingFont7 = new Font("Arial", Font.BOLD, 25);
        jl6.setFont(semiheadingFont7);
        jf.add(jl6);

        JTextField jt6 = new JTextField();
        jt6.setBounds(350, 190, 150, 25);
        Font semiheadingFont8 = new Font("Arial", Font.BOLD, 18);
        jt6.setFont(semiheadingFont8);
        jf.add(jt6);

        JLabel jl9 = new JLabel("Specialization");
        jl9.setBounds(20, 220, 300, 40);
        jl9.setForeground(new Color(0,0,0));
        Font semiheadingFont07 = new Font("Arial", Font.BOLD, 25);
        jl9.setFont(semiheadingFont07);
        jf.add(jl9);

        JTextField jt9 = new JTextField();
        jt9.setBounds(350, 220, 150, 25);
        Font semiheadingFont08 = new Font("Arial", Font.BOLD, 18);
        jt9.setFont(semiheadingFont08);
        jf.add(jt9);

        //right side=====================================================================
        JLabel jl23 = new JLabel("Working Hours");
        jl23.setBounds(700, 100, 300, 40);
        jl23.setForeground(new Color(0,0,0));
        Font semiheadingFont21 = new Font("Arial", Font.BOLD, 25);
        jl23.setFont(semiheadingFont21);
        jf.add(jl23);

        JTextField jt23 = new JTextField();
        jt23.setBounds(1100, 100, 150, 25);
        Font semiheadingFont22 = new Font("Arial", Font.BOLD, 18);
        jt23.setFont(semiheadingFont22);
        jf.add(jt23);

        JLabel jl24 = new JLabel("Employment Status");
        jl24.setBounds(700, 130, 300, 40);
        jl24.setForeground(new Color(0,0,0));
        Font semiheadingFont23 = new Font("Arial", Font.BOLD, 25);
        jl24.setFont(semiheadingFont23);
        jf.add(jl24);

        JTextField jt24 = new JTextField();
        jt24.setBounds(1100, 130, 150, 25);
        Font semiheadingFont24 = new Font("Arial", Font.BOLD, 18);
        jt24.setFont(semiheadingFont24);
        jf.add(jt24);

        JLabel jl25 = new JLabel("Working Type");
        jl25.setBounds(700, 160, 300, 40);
        jl25.setForeground(new Color(0,0,0));
        Font semiheadingFont25 = new Font("Arial", Font.BOLD, 25);
        jl25.setFont(semiheadingFont25);
        jf.add(jl25);

        JTextField jt25 = new JTextField();
        jt25.setBounds(1100, 160, 150, 25);
        Font semiheadingFont26 = new Font("Arial", Font.BOLD, 18);
        jt25.setFont(semiheadingFont26);
        jf.add(jt25);

        JLabel jl26 = new JLabel("Salary");
        jl26.setBounds(700, 190, 300, 40);
        jl26.setForeground(new Color(0,0,0));
        Font semiheadingFont27 = new Font("Arial", Font.BOLD, 25);
        jl26.setFont(semiheadingFont27);
        jf.add(jl26);

        JTextField jt26 = new JTextField();
        jt26.setBounds(1100, 190, 150, 25);
        Font semiheadingFont28 = new Font("Arial", Font.BOLD, 18);
        jt26.setFont(semiheadingFont28);
        jf.add(jt26);

        JLabel jl28 = new JLabel("Qualification");
        jl28.setBounds(700, 220, 300, 40);
        jl28.setForeground(new Color(0,0,0));
        Font semiheadingFont31 = new Font("Arial", Font.BOLD, 25);
        jl28.setFont(semiheadingFont31);
        jf.add(jl28);

        JTextField jt28 = new JTextField();
        jt28.setBounds(1100, 220, 150, 25);
        Font semiheadingFont32 = new Font("Arial", Font.BOLD, 18);
        jt28.setFont(semiheadingFont32);
        jf.add(jt28);

        JButton jb1 = new JButton("Change to Lecturer");
        jb1.setBounds(1100, 660, 150, 32);
        Font semiheadingFont01 = new Font("Arial", Font.BOLD, 12);
        jb1.setFont(semiheadingFont01);
        jf.add(jb1);
        jb1.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    jf.dispose();
                    m1();
                }
  });

        //=============================================================
        JButton jb2 = new JButton("Display");
        jb2.setBounds(1025, 300, 130, 32);
        Font semiheadingFont02 = new Font("Arial", Font.BOLD, 12);
        jb2.setFont(semiheadingFont02);
        jf.add(jb2);

        jb2.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent ae) {
        boolean hasTutor = false;
        
        StringBuilder details = new StringBuilder();
        for (Teacher t : list0) { // Ensure 'list' is the correct name of your teacher list variable
            if (t instanceof Tutor) {
                if (!hasTutor) { // Only set to true the first time a lecturer is found
                    hasTutor = true;
                }
                Tutor T1 = (Tutor) t;
               
                T1.displayDetails();
                
            }
        }

        if (!hasTutor) {
            JOptionPane.showMessageDialog(null, " No Tutor Added");
        } else {
            JOptionPane.showMessageDialog(null, "Tutor Details are Displayed\n" + details.toString());
        }
    }
});

        //===================================================================
        JButton jb3 = new JButton("Remove Tutor");
        jb3.setBounds(125, 300, 130, 32);
        Font semiheadingFont03 = new Font("Arial", Font.BOLD, 12);
        jb3.setFont(semiheadingFont03);
        jf.add(jb3);

        jb3.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent ae) {
        //'b1' is the JTextField where the teacher's ID is entered.
        int teacherId = -1;
        try {
            teacherId = Integer.parseInt(jt3.getText().trim());  // Get the ID and trim any white space
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid Teacher ID");
            jt3.setText("");  // Clear the input field to avoid confusion
            return;
        }

        boolean found = false;
        for (Teacher t : list0) {
            if (t instanceof Tutor && t.getTeacherId() == teacherId) {
                Tutor tutor = (Tutor) t;
                tutor.removeTutor();  // removeTutor() is a method that resets the tutor's attributes
                found = true;
                JOptionPane.showMessageDialog(null, "Tutor details have been reset successfully");
                break;
            }
        }


        if (!found) {
            JOptionPane.showMessageDialog(null, "No Tutor found with ID: " + teacherId);
        }

        b1.setText("");  // Clear the field after processing
    }
});

        //===============================================================
        
        JButton jb6 = new JButton("Add Tutor");
        jb6.setBounds(580, 280, 130, 32);
        Font semiheadingFont09 = new Font("Arial", Font.BOLD, 12);
        jb6.setFont(semiheadingFont09);
        jf.add(jb6);

        jb6.addActionListener(new ActionListener() {
 public void actionPerformed(ActionEvent ae) {
     try {
                        int teacherId = Integer.parseInt(jt3.getText());
                        String teacherName = jt4.getText();
                        String address = jt5.getText();
                        int performanceIndex= Integer.parseInt(jt6.getText());
                        int workingHours = Integer.parseInt(jt23.getText());
                        String employmentStatus = jt24.getText();
                        String workingType = jt25.getText();
                        String specialization = jt9.getText();
                        int salary = Integer.parseInt(jt26.getText());
                        String academicQualification  = jt28.getText();
                         // Check if a Tutor with the same teacherId already exists
            boolean exists = false;
            for (Teacher t : list0) {
                if (t instanceof Tutor && t.getTeacherId() == teacherId) {
                    exists = true;
                    break;
                }
        }

            if (exists) {
                JOptionPane.showMessageDialog(null, "Tutor with ID " + teacherId + " already exists!");
            } else {
                // Create a Tutor object and add to the ArrayList if the ID is not found
                Tutor T1 = new Tutor(teacherId,teacherName,address,workingType,employmentStatus,workingHours,salary,specialization,academicQualification,performanceIndex);
                        list0.add(T1);
                        JOptionPane.showMessageDialog(null, "!!!Thank You!!! Tutor is Added Sucessfull");
        } 
                        
                    } catch(Exception e){
                        JOptionPane.showMessageDialog(null, "Enter Correct Information of Tutor To Add Tutor");
                        
                    }
                }
});

        //Set salary=================================================

        JLabel jl002 = new JLabel("Salary & Certification");
        jl002.setBounds(400, 400, 650, 50);
        Font headingFont2 = new Font("Algerian", Font.BOLD, 45);
        jl002.setFont(headingFont2);
        jl002.setForeground(new Color(0,0,0));
        jf.add(jl002);

        JLabel jl27 = new JLabel("New Performance Index");
        jl27.setBounds(700, 520, 300, 40);
        jl27.setForeground(new Color(0,0,0));
        Font semiheadingFont29 = new Font("Arial", Font.BOLD, 25);
        jl27.setFont(semiheadingFont29);
        jf.add(jl27);

        JTextField jt27 = new JTextField();
        jt27.setBounds(1000, 520, 150, 25);
        Font semiheadingFont30 = new Font("Arial", Font.BOLD, 18);
        jt27.setFont(semiheadingFont30);
        jf.add(jt27);

        JLabel jl7 = new JLabel("New Salary");
        jl7.setBounds(60, 520, 300, 40);
        jl7.setForeground(new Color(0,0,0));
        Font semiheadingFont9 = new Font("Arial", Font.BOLD, 25);
        jl7.setFont(semiheadingFont9);
        jf.add(jl7);

        JTextField jt8 = new JTextField();
        jt8.setBounds(350, 520, 150, 25);
        Font semiheadingFont10 = new Font("Arial", Font.BOLD, 18);
        jt8.setFont(semiheadingFont10);
        jf.add(jt8);

        //Set Salary button ===========================================

        JButton jb4 = new JButton("Clear");
        jb4.setBounds(1025, 600, 130, 32);
        Font semiheadingFont04 = new Font("Arial", Font.BOLD, 12);
        jb4.setFont(semiheadingFont04);
        jf.add(jb4);

        jb4.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent ae) {
                    jt3.setText("");
                    jt4.setText("");
                    jt5.setText("");
                    jt6.setText("");
                    jt23.setText("");
                    jt24.setText("");
                    jt25.setText("");
                    jt26.setText("");
                    jt27.setText("");
                    jt8.setText("");
                    jt28.setText("");
                    jt9.setText("");
                    JOptionPane.showMessageDialog(null, "Cleared");
                }

});

        //===================================================================================
        JButton jb5 = new JButton("Set Salary");
        jb5.setBounds(125, 600, 180, 32);
        Font semiheadingFont05 = new Font("Arial", Font.BOLD, 12);
        jb5.setFont(semiheadingFont05);
        jf.add(jb5);

        

        jb5.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    try {
                        int newSalary = Integer.parseInt(jt8.getText());
                        int newPerformanceIndex = Integer.parseInt(jt27.getText());
                        for(Teacher t :list0){
                            if (t instanceof Lecturer){
                                //downcasting
                            Tutor T1 = (Tutor) t;
                            T1.setSalaryAndCertification(newSalary,newPerformanceIndex);

                            }
                        }
                        JOptionPane.showMessageDialog(null, "!!!Thank You!!! Set salary is Added Sucessfull");
                    } catch(Exception e){
                        JOptionPane.showMessageDialog(null, "enter Correct Information to Add Set salary");
                        
                    }
                }
        });
       
       
        jf.setVisible(true);

        JPanel Panel1 = new JPanel();
        Panel1.setBounds(0,0,1300,760);
        Panel1.setBackground(Color.GRAY);
        jf.add(Panel1);

    }

    public static void main (String[]args)
    {
        TeacherGUI g = new TeacherGUI();
        g.m1();
    }
}