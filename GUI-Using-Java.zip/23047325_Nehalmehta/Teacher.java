class Teacher //Teacher class defined
{
    private int teacherId;//Private variables declared for the class
    private String teacherName;
    private String address;
    private String workingType;
    private String employmentStatus;
    private int workingHours;
    //constructor is defined for class which accepts 5 parameter 
    public Teacher(int teacherId, String teacherName, String address, String workingType, String employmentStatus,int workingHours) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.address = address;
        this.workingType = workingType;
        this.employmentStatus = employmentStatus;
        this.workingHours = workingHours;
    }
    //accessor method is created for private variable
    public int getTeacherId() { 
        return teacherId;
    }

    public String getTeacherName() { 
        return teacherName;
    }

    public String getAddress() { 
        return address;
    }

    public String getWorkingType() { 
        return workingType;
    }

    public String getEmploymentStatus() { 
        return employmentStatus;
    }

    public int getWorkingHours() {  
        return workingHours;
    }

    //mutator method is created for private variable
    public void setWorkingHours(int newWorkingHours) {;
    }

    //method  is created to display Teacher's details
    public void displayDetails() {
        System.out.println("Teacher ID: " + teacherId);
        System.out.println("Teacher Name: " + teacherName);
        System.out.println("Address: " + address);
        System.out.println("Working Type: " + workingType);
        System.out.println("Employment Status: " + employmentStatus);

        if (workingHours == 0) {
            System.out.println("Working Hours: Not assigned");
        } else {
            System.out.println("Working Hours: " + workingHours);
        }
    }
}