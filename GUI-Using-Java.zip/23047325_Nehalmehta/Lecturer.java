//Lecturer class is created which inherits Teacher
public class Lecturer extends Teacher {
private String department;//private variable is declared for Lecturer
private int yearsOfExperience;
private int gradedScore;
private boolean hasGraded;
//constructor is defined for the class which accepts seven parameters
public Lecturer(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                    String department, int yearsOfExperience,int workingHours) {
        super(teacherId, teacherName, address, workingType, employmentStatus,workingHours); //super class setter is called.
        this.department =department;
        this.yearsOfExperience = yearsOfExperience;
        this.gradedScore = 0;
        this.hasGraded = false;
    }
    //acessor method is created for private class
public String getDepartment() {
        return department;
    }
public int getYearsOfExperience() {
        return yearsOfExperience;
    }

public int getGradedScore() {
        return gradedScore;
    }

public boolean gethasGraded() { 
        return hasGraded;
    }
    //mutator method is created to set GradedScore
public void setGradedScore(int newGradedScore) {
        this.gradedScore = newGradedScore;
    }
    //method is created to return gradeAssigment
public void gradeAssignment(int score, String Department, int YearsOfExperience) {
        if (!hasGraded && yearsOfExperience >= 5 && department.equals(Department)) {
            this.gradedScore = score;
            if (score >= 70) {
                System.out.println("A");
            } else if (score >= 60) {
                System.out.println("B"); 
            } else if (score >= 50) {
                System.out.println("C"); 
            } else if (score >= 40) {
                System.out.println("D"); 
            } else {
                gradedScore = 0;
            }

            hasGraded = true;
        } else {
            System.out.println("Assignment not graded yet or conditions not met.");
        }
    }
    //method is created to display lecturer details
public void displayDetails() {
        super.displayDetails();//
        System.out.println("Department: " + department);
        System.out.println("Years of Experience: " + yearsOfExperience);
        if (hasGraded) {
            System.out.println("Graded Score: " + gradedScore);
        } else {
            System.out.println("Graded Score: Not graded yet");
        }
    }
}