//Tutor class is created which inherit Teacher
public class Tutor extends Teacher {
    private double salary;//private variable is declared for tutor
    private String specialization;
    private String academicQualifications; 
    private int performanceIndex; 
    private boolean isCertified;  
    // Constructor is created which accepts ten parameters
    public Tutor(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                 int workingHours, double salary, String specialization, String academicQualifications,
                 int performanceIndex) {
        super(teacherId, teacherName, address, workingType, employmentStatus,workingHours);//super class setter is called
        super.setWorkingHours(workingHours);
        this.salary = salary;
        this.specialization = specialization;
        this.academicQualifications = academicQualifications;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;
    }

    // Accessor methods is created for private class
    public double getSalary() { 
        return salary;
    }

    public String getSpecialization() {  
        return specialization;
    }

    public String getAcademicQualifications() { 
        return academicQualifications;
    }

    public int getPerformanceIndex() { 
        return performanceIndex;
    }

    public boolean getisCertified() {  
        return isCertified;
    }

    // mutator Method to set salary and certification status
    public void setSalaryAndCertification(double newSalary, int newPerformanceIndex) {
        double appraisalPercentage;
        performanceIndex = newPerformanceIndex;
        if (newPerformanceIndex >= 5 && getWorkingHours() > 20)
        {
            
        if (newPerformanceIndex >= 5 && newPerformanceIndex <= 7)
        {
                appraisalPercentage = 0.05;
        } else if (newPerformanceIndex >= 8 && newPerformanceIndex <= 9) {
                appraisalPercentage = 0.1;
            } else {
                appraisalPercentage = 0.2;
            }

            salary = newSalary + (appraisalPercentage * newSalary);
            isCertified = true;
        } else {
            System.out.println("Salary cannot be approved. Tutor is not certified yet.");
        }
    }

    // Method is created inorder to remove tutor
    public void removeTutor() {
        if (isCertified) {
            salary = 0;
            specialization = "";
            academicQualifications = "";
            performanceIndex = 0;
            //isCertified = false;
        }
        else {
         System.out.println("Tutor cannot be remove.");
        }
            
    }

    // Display method is created to display tutor details
    public void displayDetails() {
        super.displayDetails(); // Call the displayDetails method in the parent class

        if (isCertified) { 
            System.out.println("Salary: " + salary);
            System.out.println("Specialization: " + specialization);
            System.out.println("Academic Qualifications: " + academicQualifications);
            System.out.println("Performance Index: " + performanceIndex);
        }
        else{ System.out.println("Tutor not certified.");}
    }
}